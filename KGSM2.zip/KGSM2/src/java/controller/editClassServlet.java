/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ClassDAO;
import model.ClassBean;

/**
 *
 * @author Win8
 */
public class editClassServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)    
                        throws ServletException, java.io.IOException { 
                
        ClassDAO editClassDAO = new ClassDAO();
        ClassBean classBean = new ClassBean();
        
        String cn = request.getParameter("className");
        classBean.setclass_Name(cn);
        String cc = request.getParameter("classCategory");
        classBean.setclass_Category(cc);
        String id=request.getParameter("id");
        classBean.setclass_ID(id);
        String cv = request.getParameter("classVenue");
        classBean.setclass_Venue(cv);
        classBean.setclass_Date(request.getParameter("classDate"));
        classBean.setclass_Time(request.getParameter("classTime"));
        String cp = request.getParameter("classPayment");
        classBean.setclass_Payment(cp);
        String cId = request.getParameter("coachName");
        classBean.setCoach_ID(cId);
        String cd = request.getParameter("classDescription");
        classBean.setclass_Desc(cd);
       
        
        String updateClass = editClassDAO.updateClass(classBean);
        if(updateClass.equals("SUCCESS"))
        {
            System.out.print("Your PROFILE Have Successfully UPDATED");
            
                request.getRequestDispatcher("viewClassAdmin.jsp").forward(request,response);
           
        }
        else
        {
            request.setAttribute("errMessage",updateClass);
            //JOptionPane.showMessageDialog(null,"error password/username");
            //request.getRequestDispatcher("invalidLogin.jsp").forward(request,response);
            response.sendRedirect("editClassAdmin.jsp");
        }
        }
    }
    
