/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author User
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author
 */
import java.sql.*;
import java.util.*;
import java.sql.*;
import model.ClassBean;

public class ClassDAO {
    
    static Connection currentCon = null; 
    
    public static ClassBean addClass(ClassBean classes){
    
       
        String class_Name =classes.getclass_Name(); 
        String class_Desc = classes.getclass_Desc(); 
        String class_Venue = classes.getclass_Venue(); 
        String class_Date = classes.getclass_Date();
        String class_Time = classes.getclass_Time();
        String class_Payment = classes.getclass_Payment();
        String coach_id = classes.getCoach_ID();
        String class_Category = classes.getclass_Category ();
        
        
        PreparedStatement statement;
        PreparedStatement statement2;
            
        try{
    
            currentCon = ConnectionManager.getConnection(); 
            PreparedStatement ps = currentCon.prepareStatement("INSERT INTO CLASSES(CLASSNAME,CLASSVENUE,CLASSDATE, CLASSTIME, CLASSPAYMENT, CLASSDESC, COACHID,CLASSCATEGORY)"+"values(?,?,?,?,?,?,?,?)");

            //ps.setString(1, class_ID);
            ps.setString(1, class_Name);
            ps.setString(3, class_Date);
            ps.setString(2, class_Venue);
            ps.setString(5, class_Payment);
            ps.setString(6, class_Desc);
            ps.setString(4, class_Time);
            ps.setString(7, coach_id);
            ps.setString(8, class_Category);
            
            ResultSet rs = null;
            Statement stmt;
            String searchQuery;
            stmt = currentCon.createStatement();
    
            int i = ps.executeUpdate();

            String msg=" ";
                if(i!=0){ 
                    searchQuery = "SELECT NO FROM CLASSES WHERE CLASSNAME='" + class_Name + "'";
                    
                    System.out.print(searchQuery);
                    rs = stmt.executeQuery(searchQuery);
                    while(rs.next())
                    {
                        int no = rs.getInt("NO");
                        System.out.print(no);
                        String class_ID = "WA0" + no;
                        
                        
                        statement2 = currentCon.prepareStatement("UPDATE CLASSES SET CLASSID = ? WHERE NO = ?");
                        
                        statement2.setString(1, class_ID); 
                        statement2.setInt(2, no); 
                        
                        int m = statement2.executeUpdate();
                        
                        if(m!=0){
                            msg="Record has been inserted";
                            System.out.println("<font size='6' color=blue>" + msg + "</font>"); 
                            classes.setValid(true);
                        }
                        else{  
                            msg="Failed to insert the data";
                            System.out.println("<font size='6' color=blue>" + msg + "</font>");
                            classes.setValid(false);
                        }
                    } 
                }  
                else{  
                    msg="Failed to insert the data";
                    System.out.println("<font size='6' color=blue>" + msg + "</font>");
                }
            }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally{
    
            if (currentCon != null){
                try{
                    currentCon.close();
                }catch(Exception e){
                    currentCon = null;
                }
            }
        }
        return classes;
    }
    
    // UPDATE CLASS 
    public String updateClass(ClassBean classBean) {
        
        Connection con;
        PreparedStatement statement;
        PreparedStatement statement2;
        //ResultSet resultSet;
        try
        {   
        String class_ID = classBean.getclass_ID();
        String class_Name =classBean.getclass_Name(); 
        String class_Desc = classBean.getclass_Desc(); 
        String class_Venue = classBean.getclass_Venue(); 
        String class_Date = classBean.getclass_Date();
        String class_Time = classBean.getclass_Time();
        String class_Payment = classBean.getclass_Payment();
        String coach_ID = classBean.getCoach_ID();
        String class_Category = classBean.getclass_Category ();
        con = ConnectionManager.getConnection();

            ResultSet rs = null;
            Statement stmt;
            String searchQuery;
            stmt = con.createStatement();
                statement = con.prepareStatement("UPDATE CLASSES SET CLASSNAME=?,CLASSCATEGORY=?,CLASSVENUE=?,CLASSDATE=?, CLASSTIME=?,CLASSPAYMENT=?,CLASSDESC=?,COACHID=? WHERE CLASSID =?");
                statement.setString(1, class_Name); 
                statement.setString(2, class_Category); 
                statement.setString(3, class_Venue);         
                statement.setString(4, class_Date); 
                statement.setString(5, class_Time);
                statement.setString(6, class_Payment); 
                statement.setString(7, class_Desc); 
                statement.setString(8, coach_ID);
                statement.setString(9, class_ID);
                
                
                //resultSet = statement.executeQuery("INSERT INTO COACH(COACHFULLNAME,COACHNAME, COACHPASSWORD,COACHIC, COACHEMAIL,COACHPHONENO, COACHADDRESS, USERTYPEID, USERTYPEDESC) VALUES('"+fullName+"','"+userName+"', '"+password+"','"+ic+"', '"+email+"', '"+phoneNo+"', '"+address+"', 2 ,'PENGAJAR')");
                int i = statement.executeUpdate();
                System.out.print("dao"+i);
                String msg;
                if(i!=0){
                            msg="SUCCESSFULLY UPDATED";
                            System.out.println("<font size='6' color=blue>" + msg + "</font>"); 
                            return "SUCCESS";
                        }
                        else{  
                            msg="Failed to UPDATE the data";
                            System.out.println("<font size='6' color=blue>" + msg + "</font>");
                        }
        }   

        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return "Failed";
    }
}
    
   