/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author tiqah isza
 */
public class ReportBean {
    private String month;
    
    public String getMonth()
    {
        return month;
    }
    
    public void setMonth(String newMonth)
    {
        month = newMonth;
    }
}
